#include<stdio.h>
#include<unistd.h>
void main()
{
    int pr,p[2];
    char str[15],str1[15];
    pipe(p);
    pr=fork();
    if(pr<0){
        printf("error");
    }
    else{
        if(pr>0)
        {
        printf("enter string for 1st end:");
        gets(str);
        write(p[1],str,15);
        close(p[1]);
        }
        else
        {
        printf("reading string from 2nd end:");
        read(p[0],str1,15);
        printf("%s\n",str1);
        close(p[0]);
        }
    }
}
