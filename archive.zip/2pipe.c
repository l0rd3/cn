#include<stdio.h>
#include<unistd.h>
void main()
{
    int pr,p[2],p1[2];
    char str[15],str1[15],str2[15],str3[4];
    pipe(p);
    pipe(p1);
    pr=fork();
    if(pr<0)
    {
        printf("error");
    }
    else
    {
        if(pr>0)
        {
            printf("Writing to parent end:");
            scanf("%s",str);
            write(p[1],str,15);
            read(p1[0],str3,15);
            printf("Reading from parent end:%s\n",str3);
            close(p[1]);
            close(p1[0]);
        }
        else
        {
            read(p[0],str1,15);
            printf("Writing to Child end:");
            scanf("%s",str2);
            write(p1[1],str2,15);
            printf("Reading from Child end:%s\n",str1);
            close(p[0]);
            close(p1[1]);
        }
    }
}
