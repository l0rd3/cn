#include<stdio.h>
#include<unistd.h>
void main()
{
	int pr,pid1,pid2,pid3,pid4;
	pr=fork();

	if(pr<0){
		printf("error");
	}
	else{
		if(pr>0)
		{
			printf("I am Parent\n");
			pid1=getpid();
			printf("My ID:%d\t",pid1);
			pid2=getppid();
			printf("My parent ID:%d\n\n",pid2);
		}
		else
		{
			printf("I am Child\n");
                        pid3=getpid();
                        printf("My ID:%d\t",pid3);
                        pid4=getppid();
                        printf("My parent ID:%d\n",pid4);

		}
	}
}
