import java.io.*;
import java.net.*;
import java.util.*;

public class server{
static HashMap<String,Socket> clients = new HashMap<String,Socket>();
public static void main(String args[])throws Exception
{

ServerSocket ss = new ServerSocket(6666);

while(true){
	Socket s = ss.accept();
	String cname = getData(s);
	clients.put(cname,s);
	System.out.println("Client connected :"+ cname);
	new Thread(new Runnable(){
	@Override
	public void run(){
		try{
			String data = getData(s);
			Socket target = clients.get(data);
			PrintWriter pw = new PrintWriter(target.getOutputStream());
			while(true){
				data = getData(s);
				pw.println(data);
				pw.flush();
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	}).start();
}

}

public static String getData(Socket s)throws IOException{
	return new BufferedReader(new InputStreamReader(s.getInputStream())).readLine();
}
}
