#include<stdio.h>
#include<stdlib.h>
int main(int argc,char *argv[])
{
	char c;
	FILE *fptr,*fptr1,*fptr2;
	fptr=fopen(argv[1], "r");
	fptr1=fopen(argv[2], "r");
	fptr2=fopen(argv[3], "w");
	while ((c = fgetc(fptr)) != EOF)
	fputc(c, fptr2);
	while ((c = fgetc(fptr1)) != EOF)
	fputc(c, fptr2);
	fclose(fptr);
	fclose(fptr1);
	fclose(fptr2);
	printf("File Concatenated.\n");
}
