import java.io.*;
import java.net.*;
public class stcp
{
public static void main(String[] args) throws Exception
{
ServerSocket ss = new ServerSocket(6666);
Socket s = ss.accept();
BufferedReader br1 = new BufferedReader(new InputStreamReader(System.in));
BufferedReader br2 = new BufferedReader(new InputStreamReader(s.getInputStream()));
PrintWriter pw = new PrintWriter(s.getOutputStream());
String msg;



while(true)
{
	msg = br2.readLine();
	System.out.println("Client:"+msg);
	if(msg.equals("bye"))
                System.exit(0);
	pw.println("Message Received");
        pw.flush();

	System.out.println("Enter a message:");
	msg= br1.readLine();
	pw.println(msg);
	pw.flush();
	msg = br2.readLine();
        System.out.println("Server:"+msg);
	if(msg.equals("bye"))
                System.exit(0);

}

}

}


