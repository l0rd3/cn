import java.io.*;
import java.net.*;

public class client
{
public static void main(String args[])throws Exception
{

Socket s = new Socket("localhost",6666);
BufferedReader br1 = new BufferedReader(new InputStreamReader(System.in));
BufferedReader br2 = new BufferedReader(new InputStreamReader(s.getInputStream()));
PrintWriter pw = new PrintWriter(s.getOutputStream());
String msg,username,target;
System.out.println("Enter username:");
username = br1.readLine();
pw.println(username);
pw.flush();
System.out.println("Enter target user:");
target = br1.readLine();
pw.println(target);
pw.flush();

new Thread(new Runnable(){
	@Override
	public void run()
	{
		try{
		while(true){
			String rcv = br2.readLine();
			System.out.println(target+":"+rcv);
			if(rcv.equals("bye"))
				System.exit(0);
		}	
		}
		catch(IOException e){
			e.printStackTrace();
		}
	}
}).start();

while(true){
	msg = br1.readLine();
	pw.println(msg);
	pw.flush();
	if(msg.equals("bye"))
		System.exit(0);
}

}

}
